
#ifndef GENERIC_FILE_FUNCTIONS_H
#define GENERIC_FILE_FUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "global_variables.h"
#include "generic_memory_allocation_functions.h"
#include "text_functions.h"
#include "error_handling.h"

/* Function prototypes */

/* Function to open the file for reading and handle errors */
int open_file_for_reading(const char *file_name, FILE **fp);

/* Function to open the file for writing and handle errors */
int open_file_for_writing(const char *file_name, FILE **fp_out);

/* Function to create a new file name with the specified extension */
char *create_new_file_name(const char *base_file_name, const char *extension);

/* Function to copy the contents of one file to another */
int copy_file(const char *destination_file_name, const char *source_file_name);

/**
 * @brief Cleans up the specified file by deleting it and freeing the memory allocated for the file path.
 *
 * This function removes the file located at the given file path.
 * The function also frees the memory allocated for the file path.
 *
 * @param file_path A pointer to the file path to be cleaned up. The memory allocated for
 *                  this file path will be freed by this function.
 */
void cleanup_file(char *file_path);

/* Function to remove extra spaces in a given line */
void remove_extra_spaces_in_line(char line[]);

/* Function to remove extra spaces from a file and save the result to a new file */
char *remove_extra_spaces_in_file(char file_name[]);

/* Function to copy text from a file starting at a given position up to a specified length */
char *copy_text(FILE *fp, fpos_t *start_pos, int text_length);

#endif /* UTILS_H */
